# Login
def login_process(username, password):
    with open('passwd.txt', 'r') as file:
        for line in file:
            fields = line.split(':')
            if fields[0] == username and fields[2].strip() == password:
                return True
    return False

if __name__ == "__main__":
    login_username = input("User:     ")
    login_password = input("Password: ")

    if login_process(login_username, login_password):
        print("Access granted.")
    else:
        print("Access denied.")


# Delete user
def userRemove(username):
    with open('passwd.txt', 'r') as file:
        lines = file.readlines()

    with open('passwd.txt', 'w') as file:
        for line in lines:
            if not line.startswith(username + ":"):
                file.write(line)

    print("User Removed.")

if __name__ == "__main__":
    username_delete = input("Enter username: ")
    userRemove(username_delete)
