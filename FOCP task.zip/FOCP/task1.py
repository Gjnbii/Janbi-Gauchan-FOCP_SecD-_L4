def price_calculation(is_tuesday: bool, pizzas_number: int, is_delivery: bool, is_ordered_viaApp: bool) -> float:
   
    one_pizza_price = 12
    deliveryCost = 2.5 if pizzas_number < 5 and is_delivery else 0
    
    total_cost = pizzas_number * one_pizza_price
   
    if is_tuesday:
        total_cost *= 0.5

    if is_ordered_viaApp:
        total_cost *= 0.75
    
    total_price = total_cost + deliveryCost
    return total_price

print("BPP Pizza Price Calculator")
print("==========================")


pizzas_number = -1
while pizzas_number <= 0:
    try:
        pizzas_number = int(input("How many pizzas would you like to order? "))
        if pizzas_number < 0:
            print("Please enter a positive integer!")
    except ValueError:
            print("Please enter a number!")

while True:
    is_tuesday = input("Is it Tuesday? ")
    if is_tuesday.lower() == "yes":
        break
    elif is_tuesday.lower() == "no":
        break
    else:
        print('Please answer "yes" or "no".')
                
                
while True:
    is_delivery = input("Is delivery required? ")
    if is_delivery.lower() == "yes":
        break
    elif is_delivery.lower() == "no":
        break
    else:
        print('Please answer "yes" or "no".')
                
                
while True:
    is_ordered_viaApp = input("Did the customer use the app? ")
    if is_ordered_viaApp.lower() == "yes":
        break
    elif is_ordered_viaApp.lower() == "no":
        break
    else:
        print('Please answer "yes" or "no".')

# Calculate and display the total price
total_price = price_calculation(is_tuesday.lower() == "yes", pizzas_number, is_delivery.lower() == "yes", is_ordered_viaApp.lower() == "yes")
print(f"\n{f'Total Price: £{total_price:.2f}':}")
 