#4.  When processing data it is often useful to remove the last character from some
# input (it is often a newline). Write and test a function that takes a string parameter
# and returns it with the last character removed. (If the string contains one or fewer
# characters, return it unchanged.)
def name(x):
    z=x[0:len(x)-1]
    print(z)
y=input("enter a word: ")
name(y) 