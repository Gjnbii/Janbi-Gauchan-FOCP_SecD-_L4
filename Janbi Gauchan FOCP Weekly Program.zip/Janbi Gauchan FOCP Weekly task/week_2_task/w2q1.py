#1. Take a copy of it, and modify it so that the user enters their name at the
# keyboard, and then receives a greeting. For example:
# Hello, what is your name? Mr Apricot
# Hello, Mr Apricot. Good to meet you!
print("hello,what is your name? ")
name=input("enter your name: ")
print("hello,",name, 'nice to meet you')